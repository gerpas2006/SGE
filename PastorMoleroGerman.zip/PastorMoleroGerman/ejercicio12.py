# Escribe una función contador_likes(*likes_por_dia) que reciba un número variable de enteros (likes de cada día) y devuelva: 
# (Si no lo sabes, busca qué significa el asterisco como parte del parámetro de una función en Python) - 
# El total de likes. - La media de likes. - El día con más likes (posición empezando en 1). 
